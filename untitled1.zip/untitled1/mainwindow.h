#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QDialog>
#include <QTextEdit>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void enrollInCourse();
    void submitAssignment();
    void viewCourseContent();
    void assignGrade();
    void filterCourses(const QString &text);
    void changeRole(const QString &role);

private:
    void updateDashboard();
    void updateGradesTab();
    void showContentDialog(const QString &course);

    Ui::MainWindow *ui;  // Pointer to the generated UI class

    // Mock data
    QStringList enrolledCourses;
    QStringList availableCourses = {"OOP", "Digital Design", "Functional English"};
    QStringList assignments = {"HW1: Basic Loops", "HW2: Arrays", "Project: Build a Calculator"};
    QStringList announcements = {"New course available: AI Basics", "Assignment deadline extended", "System maintenance tonight"};
    QMap<QString, QString> courseContent;  // Course -> Content description
    QMap<QString, QString> grades;  // Assignment -> Grade (for students)
    QString currentRole = "Student";  // Default role
};

#endif // MAINWINDOW_H
