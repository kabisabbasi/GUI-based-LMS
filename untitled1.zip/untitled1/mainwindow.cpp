#include "mainwindow.h"
#include "ui_mainwindow.h"  // Include the generated UI header
#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QDialog>
#include <QTextEdit>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);  // Load the UI from the .ui file

    setWindowTitle("LMS");
    setMinimumSize(600, 400);  // Prevents the window from being too small

    // Connect signals from UI widgets to slots
    connect(ui->enrollButton, &QPushButton::clicked, this, &MainWindow::enrollInCourse);
    connect(ui->submitButton, &QPushButton::clicked, this, &MainWindow::submitAssignment);
    connect(ui->viewContentButton, &QPushButton::clicked, this, &MainWindow::viewCourseContent);
    connect(ui->assignGradeButton, &QPushButton::clicked, this, &MainWindow::assignGrade);
    connect(ui->searchBar, &QLineEdit::textChanged, this, &MainWindow::filterCourses);
    connect(ui->roleComboBox, QOverload<const QString &>::of(&QComboBox::currentTextChanged), this, &MainWindow::changeRole);

    // Initialize lists and tables
    ui->courseList->addItems(availableCourses);
    ui->assignmentList->addItems(assignments);

    // Initialize mock course content
    courseContent["OOP"] = "Module 1: Variables\nModule 2: Loops\nVideo: Intro Lecture";
    courseContent["Digital Design"] = "Module 1: Truth Table\nModule 2: K-Maps\nVideo: Logic Gates";
    courseContent["Functional English"] = "Module 1: Essay Writing\nModule 2: Grammar";
    // In mainwindow.cpp, inside MainWindow::MainWindow(QWidget *parent), after setCentralWidget(...)
    QString styleSheet = R"(
    /* Overall app background and font */
    QMainWindow {
        background-color: #f5f5f5;
        font-family: 'Segoe UI', Arial, sans-serif;
        font-size: 10pt;
    }

    /* Toolbar styling */
    QToolBar {
        background-color: #ffffff;
        border-bottom: 1px solid #e0e0e0;
        padding: 5px;
    }

    /* Tab widget */
    QTabWidget::pane {
        border: 1px solid #cccccc;
        background-color: #ffffff;
    }
    QTabBar::tab {
        background-color: #f0f0f0;
        border: 1px solid #cccccc;
        padding: 8px 16px;
        margin-right: 2px;
        border-radius: 4px;
    }
    QTabBar::tab:selected {
        background-color: #0078d4;
        color: white;
        font-weight: bold;
    }
    QTabBar::tab:hover {
        background-color: #e0e0e0;
    }

    /* Buttons */
    QPushButton {
        background-color: #0078d4;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-weight: bold;
    }
    QPushButton:hover {
        background-color: #005a9e;
    }
    QPushButton:pressed {
        background-color: #004578;
    }
    QPushButton:disabled {
        background-color: #cccccc;
        color: #666666;
    }

    /* Lists (e.g., courseList, assignmentList) */
    QListWidget {
        background-color: #ffffff;
        border: 1px solid #cccccc;
        border-radius: 4px;
        alternate-background-color: #f9f9f9;
    }
    QListWidget::item {
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
    }
    QListWidget::item:selected {
        background-color: #0078d4;
        color: white;
    }
    QListWidget::item:hover {
        background-color: #e0e0e0;
    }

    /* Table (gradesTable) */
    QTableWidget {
        background-color: #ffffff;
        border: 1px solid #cccccc;
        border-radius: 4px;
        gridline-color: #e0e0e0;
    }
    QTableWidget::item {
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
    }
    QHeaderView::section {
        background-color: #f0f0f0;
        padding: 8px;
        border: 1px solid #cccccc;
        font-weight: bold;
    }

    /* Labels */
    QLabel {
        color: #333333;
        font-size: 11pt;
    }

    /* Search bar */
    QLineEdit {
        border: 1px solid #cccccc;
        border-radius: 4px;
        padding: 6px;
        background-color: #ffffff;
    }
    QLineEdit:focus {
        border-color: #0078d4;
    }

    /* Combo box (role selector) */
    QComboBox {
        border: 1px solid #cccccc;
        border-radius: 4px;
        padding: 4px;
        background-color: #ffffff;
    }
    QComboBox::drop-down {
        border: none;
    }

    /* Scroll bars */
    QScrollBar:vertical {
        background-color: #f0f0f0;
        width: 12px;
        border-radius: 6px;
    }
    QScrollBar::handle:vertical {
        background-color: #cccccc;
        border-radius: 6px;
    }
    QScrollBar::handle:vertical:hover {
        background-color: #aaaaaa;
    }
)";

    qApp->setStyleSheet(styleSheet);

    // Initialize grades (empty for students)
    updateDashboard();
    updateGradesTab();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::enrollInCourse()
{
    QListWidgetItem *item = ui->courseList->currentItem();
    if (item) {
        QString course = item->text();
        if (!enrolledCourses.contains(course)) {
            enrolledCourses.append(course);
            QMessageBox::information(this, "Enrolled", "You have enrolled in: " + course);
            updateDashboard();
        } else {
            QMessageBox::warning(this, "Already Enrolled", "You are already enrolled in this course.");
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select a course to enroll.");
    }
}

void MainWindow::submitAssignment()
{
    QListWidgetItem *item = ui->assignmentList->currentItem();
    if (item) {
        QString fileName = QFileDialog::getOpenFileName(this, "Select File to Submit", "", "All Files (*)");
        if (!fileName.isEmpty()) {
            QMessageBox::information(this, "Submitted", "Assignment '" + item->text() + "' submitted successfully!");
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select an assignment to submit.");
    }
}

void MainWindow::viewCourseContent()
{
    QListWidgetItem *item = ui->courseList->currentItem();
    if (item) {
        showContentDialog(item->text());
    } else {
        QMessageBox::warning(this, "No Selection", "Please select a course to view content.");
    }
}

void MainWindow::assignGrade()
{
    if (currentRole != "Instructor") {
        QMessageBox::warning(this, "Access Denied", "Only instructors can assign grades.");
        return;
    }
    QList<QTableWidgetItem*> selected = ui->gradesTable->selectedItems();
    if (selected.size() > 0) {
        QString assignment = selected[0]->text();  // First column
        bool ok;
        QString grade = QInputDialog::getText(this, "Assign Grade", "Enter grade for " + assignment + ":", QLineEdit::Normal, "", &ok);
        if (ok && !grade.isEmpty()) {
            grades[assignment] = grade;
            updateGradesTab();
            QMessageBox::information(this, "Assigned", "Grade assigned successfully.");
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select an assignment to grade.");
    }
}

void MainWindow::filterCourses(const QString &text)
{

    ui->courseList->clear();
    for (const QString &course : availableCourses) {
        if (course.contains(text, Qt::CaseInsensitive)) {
            ui->courseList->addItem(course);
        }
    }
}

void MainWindow::changeRole(const QString &role)
{
    currentRole = role;
    updateGradesTab();  // Refresh grades based on role
    QMessageBox::information(this, "Role Changed", "Switched to " + role + " mode.");
}

void MainWindow::updateDashboard()
{
    ui->dashboardList->clear();
    ui->dashboardList->addItems(enrolledCourses);
}

void MainWindow::updateGradesTab()
{
    ui->gradesTable->setRowCount(0);
    for (const QString &assignment : assignments) {
        int row = ui->gradesTable->rowCount();
        ui->gradesTable->insertRow(row);
        ui->gradesTable->setItem(row, 0, new QTableWidgetItem(assignment));
        QString grade = grades.value(assignment, "Not Graded");
        if (currentRole == "Student") {
            grade = grade == "Not Graded" ? "Pending" : grade;  // Hide instructor details
        }
        ui->gradesTable->setItem(row, 1, new QTableWidgetItem(grade));
    }
}

void MainWindow::showContentDialog(const QString &course)
{
    QDialog dialog(this);
    dialog.setWindowTitle("Course Content: " + course);
    QVBoxLayout layout(&dialog);
    QTextEdit *contentEdit = new QTextEdit();
    contentEdit->setPlainText(courseContent.value(course, "No content available."));
    contentEdit->setReadOnly(true);
    layout.addWidget(contentEdit);
    QPushButton *closeButton = new QPushButton("Close");
    connect(closeButton, &QPushButton::clicked, &dialog, &QDialog::accept);
    layout.addWidget(closeButton);
    dialog.exec();
}
